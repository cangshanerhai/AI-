
export interface FileAttachment {
  name: string;
  type: string;
  data: string; // Base64 Data URL
}

export interface Message {
  id: string;
  text: string;
  file?: FileAttachment;
  // New: For merged chat history
  recordData?: {
    title: string;
    preview: string[]; // Lines to show on the card
    originalMessages: Message[];
    // Snapshot of the people involved in this record
    profiles: {
      me: { name: string; avatarUrl: string };
      them: { name: string; avatarUrl: string }; // 'them' maps to sender: 'ai' in the original context
    };
  };
  sender: 'me' | 'ai';
  timestamp: number;
  status?: 'sending' | 'sent' | 'error';
}

export enum Gender {
  Male = '男性',
  Female = '女性',
  NonBinary = '非二元性别',
}

export interface Persona {
  id: string;
  name: string;
  remark?: string; // 备注
  gender: Gender;
  personality: string;
  avatarUrl: string;
}

export type AIProvider = 'gemini' | 'local' | 'siliconflow';

export interface AppSettings {
  provider: AIProvider;
  
  // Gemini
  // Uses process.env.API_KEY by default in code, but we keep structure clean
  
  // Local
  localAIUrl: string; 
  
  // SiliconFlow
  siliconFlowApiKey: string;
  siliconFlowModel: string; // Chat model (e.g. DeepSeek R1)
  siliconFlowVisionModel: string; // Vision model (e.g. Qwen-VL)

  systemInstruction: string;
}

export interface UserProfile {
  name: string;
  avatarUrl: string;
}