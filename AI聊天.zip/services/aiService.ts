
import { GoogleGenAI } from "@google/genai";
import { AppSettings, Message, Persona } from "../types";

// Helper to extract raw base64 from Data URL (e.g., "data:image/png;base64,ABC..." -> "ABC...")
const extractBase64 = (dataUrl: string) => {
  return dataUrl.split(',')[1];
};

export const generateAIResponse = async (
  history: Message[],
  currentMessage: string, 
  persona: Persona,
  settings: AppSettings
): Promise<string> => {
  
  const systemInstruction = `
    你现在正在微信上聊天。
    你的名字是 "${persona.name}"。
    你的性别是 "${persona.gender}"。
    你的性格特点是: "${persona.personality}"。
    
    回复要求：
    1. 必须使用中文。
    2. 语气要像在微信上聊天一样，自然、口语化，不要像机器人。
    3. 回复尽量简短，不要长篇大论，除非话题需要。
    4. 适当使用Emoji表情。
    5. 不要每一句都用句号结尾，像现代年轻人一样聊天。
    6. 如果用户发送图片或文件，请根据图片内容进行反应。
    7. **聊天记录分析**：如果用户发送了 "[聊天记录]" 开头的内容（这是微信合并转发的格式），这代表用户转发了一段历史对话给你。**请务必仔细阅读这段记录**，然后根据用户的最近一句指令（通常是"转发"行为本身隐含的分享，或者是随后附带的"你怎么看？"等）进行回复。你可以对记录内容进行评论、总结或回答相关问题。
    
    ${settings.systemInstruction || ''}
  `;

  // Memory Optimization REMOVED: User requested to keep ALL chat records.
  // We pass the full history to the model. Note: This may hit token limits for very long chats.
  const fullHistory = history;

  // --- SiliconFlow (DeepSeek / OpenAI Compatible) ---
  if (settings.provider === 'siliconflow' || settings.provider === 'local') {
    const rawApiKey = settings.provider === 'siliconflow' ? settings.siliconFlowApiKey : 'local-key';
    const apiKey = rawApiKey?.trim();
    const baseUrl = settings.provider === 'siliconflow' ? "https://api.siliconflow.cn/v1/chat/completions" : settings.localAIUrl;
    
    let model = settings.provider === 'siliconflow' ? (settings.siliconFlowModel || "deepseek-ai/DeepSeek-R1") : "local-model";
    const visionModel = settings.siliconFlowVisionModel || "Qwen/Qwen2.5-VL-72B-Instruct";

    if (!apiKey && settings.provider === 'siliconflow') {
      return "[系统提示] 未配置 API Key。";
    }

    // Construct OpenAI-compatible Vision Payload
    let hasImages = false;

    const messagesPayload = [
      { role: 'system', content: systemInstruction },
      ...fullHistory.map(m => {
        const role = m.sender === 'me' ? 'user' : 'assistant';
        
        // If message has an image, use the multimodal content array format
        if (m.file && m.file.type.startsWith('image/')) {
           hasImages = true;
           return {
             role,
             content: [
               { type: "text", text: m.text || " " },
               { 
                 type: "image_url", 
                 image_url: { url: m.file.data } // Data URL supported by OpenAI/Compatible standard
               }
             ]
           };
        }
        
        // Regular text message (Includes 'Record' messages which have full text in m.text)
        return {
          role,
          content: m.text
        };
      })
    ];

    // If using SiliconFlow and we detected images, switch to the Vision Model
    if (settings.provider === 'siliconflow' && hasImages) {
        model = visionModel;
    }

    // Retry logic for unstable connections (SiliconFlow R1)
    let attempts = 0;
    const maxAttempts = 2;
    
    while (attempts < maxAttempts) {
        attempts++;
        try {
          const response = await fetch(baseUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify({
              model: model,
              messages: messagesPayload,
              stream: false,
              temperature: 0.6,
              max_tokens: 4096 
            })
          });

          if (!response.ok) {
            let errorMsg = response.statusText;
            try {
                const errData = await response.json();
                errorMsg = errData.message || JSON.stringify(errData);
            } catch(e) {}
            
            // If it's a 5xx error, it might be transient, throw to retry
            if (response.status >= 500) {
                 throw new Error(`Server Error ${response.status}: ${errorMsg}`);
            }
            throw new Error(`API Error (${response.status}): ${errorMsg}`);
          }

          const data = await response.json();
          let content = data.choices?.[0]?.message?.content || "[无回复]";
          
          // Clean up <think> tags for R1
          content = content.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
          
          if (!content) {
             content = data.choices?.[0]?.message?.content || "...";
          }
          
          return content;

        } catch (e: any) {
          console.error(`Attempt ${attempts} failed:`, e);
          
          // If this was the last attempt, return error
          if (attempts === maxAttempts) {
              if (e.name === 'TypeError' && e.message === 'Failed to fetch') {
                  return `[网络错误] 无法连接到服务器。可能原因：\n1. 网络不稳定\n2. 硅基流动 DeepSeek R1 模型繁忙（请稍后重试或切换模型）\n3. API Key 无效`;
              }
              return `[错误] ${e.message}`;
          }
          // Wait briefly before retry
          await new Promise(res => setTimeout(res, 1000));
        }
    }
    return "[未知错误]";
  }

  // --- Gemini Cloud API ---
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
      return "[系统提示] 缺少 API Key。";
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    
    // Construct History for Gemini
    // We treat 'fullHistory' as the full context we want to provide.
    // However, Gemini's sendMessage expects history NOT to include the very last message (which is sent in sendMessage).
    
    // Note: fullHistory includes the 'current' message because we added it in App.tsx before calling this service.
    // So for Gemini chat history, we take everything EXCEPT the last one.
    const pastMessages = fullHistory.slice(0, -1); 
    const lastMsg = fullHistory[fullHistory.length - 1];

    const geminiHistory = pastMessages.map(msg => {
        const parts: any[] = [];
        
        if (msg.text) {
          parts.push({ text: msg.text });
        }
        
        if (msg.file && msg.file.type.startsWith('image/')) {
          parts.push({
            inlineData: {
              mimeType: msg.file.type,
              data: extractBase64(msg.file.data)
            }
          });
        }
        
        // Fallback for non-image files - just say sent a file
        if (msg.file && !msg.file.type.startsWith('image/')) {
             parts.push({ text: `[发送了一个文件: ${msg.file.name}]` });
        }

        return {
            role: msg.sender === 'me' ? 'user' : 'model',
            parts: parts
        };
    });

    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
          systemInstruction: systemInstruction,
          temperature: 0.9,
      },
      history: geminiHistory
    });

    // Construct the payload for the current message
    const currentParts: any[] = [];
    if (lastMsg.text) {
        currentParts.push({ text: lastMsg.text });
    }
    if (lastMsg.file && lastMsg.file.type.startsWith('image/')) {
        currentParts.push({
            inlineData: {
                mimeType: lastMsg.file.type,
                data: extractBase64(lastMsg.file.data)
            }
        });
    } else if (lastMsg.file) {
        currentParts.push({ text: `[发送了一个文件: ${lastMsg.file.name}]` });
    }

    // Ensure we have at least something to send
    if (currentParts.length === 0) {
        currentParts.push({ text: "..." });
    }

    // Use the correct argument structure for sendMessage
    const result = await chat.sendMessage({ 
        message: currentParts
    });
    
    return result.text || "...";
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return `[网络错误] ${error.message || '无法连接到 AI 服务'}`;
  }
};
