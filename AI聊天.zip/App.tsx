
import React, { useState, useRef, useEffect } from 'react';
import { Icons, DEFAULT_AVATARS, EMOJI_LIST } from './constants';
import { Message, AppSettings, Persona, Gender, UserProfile, FileAttachment } from './types';
import { generateAIResponse } from './services/aiService';
import SettingsPanel from './components/SettingsPanel';

// Initial Settings (Fallback)
const INITIAL_SETTINGS: AppSettings = {
  provider: 'siliconflow',
  localAIUrl: 'http://localhost:11434/v1/chat/completions',
  siliconFlowApiKey: '', 
  siliconFlowModel: 'deepseek-ai/DeepSeek-R1',
  siliconFlowVisionModel: 'Qwen/Qwen2.5-VL-72B-Instruct',
  systemInstruction: '',
};

const INITIAL_USER: UserProfile = {
  name: '我',
  avatarUrl: DEFAULT_AVATARS.ME
};

// Storage Keys
const STORAGE_KEYS = {
  PROFILE: 'wechat_sim_profile',
  CONTACTS: 'wechat_sim_contacts',
  HISTORY: 'wechat_sim_history',
  SETTINGS: 'wechat_sim_settings'
};

// Helper to convert file to Base64 Data URL
const fileToDataUrl = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

function App() {
  const [activeTab, setActiveTab] = useState<'chat' | 'contacts' | 'settings'>('chat');
  
  // Data State with Persistence
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [contacts, setContacts] = useState<Persona[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONTACTS);
    return saved ? JSON.parse(saved) : [];
  });
  
  const [activeContactId, setActiveContactId] = useState<string>('');
  
  // Chat History with Persistence
  const [chatHistory, setChatHistory] = useState<Record<string, Message[]>>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return saved ? JSON.parse(saved) : {};
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });
  
  // Persistence Effects
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(chatHistory));
  }, [chatHistory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  // UI State
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  // Forwarding & Records UI State
  const [showForwardContactPicker, setShowForwardContactPicker] = useState(false);
  const [msgsToForward, setMsgsToForward] = useState<Message[]>([]);
  const [viewingRecord, setViewingRecord] = useState<Message['recordData'] | null>(null);

  // File & Emoji UI State
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{file: File, preview: string} | null>(null);

  // Selection & Context Menu State
  const [contextMenu, setContextMenu] = useState<{x: number, y: number, msgId: string} | null>(null);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedMsgIds, setSelectedMsgIds] = useState<Set<string>>(new Set());

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatFileRef = useRef<HTMLInputElement>(null);
  const contextMenuRef = useRef<HTMLDivElement>(null);

  // Derived State
  const activeContact = contacts.find(c => c.id === activeContactId);
  const activeMessages = activeContact ? (chatHistory[activeContact.id] || []) : [];

  const scrollToBottom = () => {
    // Only scroll if NOT in selection mode (to avoid jumping while selecting)
    if (!isSelectionMode) {
       messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeMessages, isTyping, activeContactId, selectedFile]);

  // Click outside to close context menu
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
        if (contextMenuRef.current && !contextMenuRef.current.contains(e.target as Node)) {
            setContextMenu(null);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // --- Message Sending ---
  const handleSendMessage = async (text: string, fileAtt?: FileAttachment, recordData?: Message['recordData'], overrideContactId?: string) => {
    const targetContactId = overrideContactId || activeContactId;
    const targetContact = contacts.find(c => c.id === targetContactId);

    if ((!text.trim() && !fileAtt && !recordData) || !targetContact) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: text,
      file: fileAtt,
      recordData: recordData,
      sender: 'me',
      timestamp: Date.now(),
      status: 'sent'
    };

    // Update UI immediately for the target contact
    setChatHistory(prev => ({
        ...prev,
        [targetContactId]: [...(prev[targetContactId] || []), userMsg]
    }));
    
    // Reset inputs if sending to current chat
    if (targetContactId === activeContactId) {
        setInputValue('');
        setSelectedFile(null);
        setShowEmojiPicker(false);
        setIsTyping(true);
    }

    // AI Response (Pass the text content, even if it's a record)
    try {
      // Get fresh history including the message just sent
      // Note: We use the function form of setState above, but we need current state here. 
      // For simplicity/safety, we grab from existing state and append manually.
      const history = chatHistory[targetContactId] || [];
      const updatedHistory = [...history, userMsg];

      // If it's the current chat, show typing. If background, maybe not needed but good for consistency.
      if (targetContactId === activeContactId) setIsTyping(true);

      const responseText = await generateAIResponse(updatedHistory, userMsg.text, targetContact, settings);
      
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: responseText,
        sender: 'ai',
        timestamp: Date.now()
      };
      
      setChatHistory(prev => ({
        ...prev,
        [targetContactId]: [...(prev[targetContactId] || []), aiMsg]
      }));

    } catch (error) {
       console.error(error);
    } finally {
      if (targetContactId === activeContactId) {
          setIsTyping(false);
          if (activeTab === 'chat') {
              setTimeout(() => inputRef.current?.focus(), 50);
          }
      }
    }
  };

  const handleInputSend = async () => {
       if (!inputValue.trim() && !selectedFile) return;
       let fileAttachment: FileAttachment | undefined;

        if (selectedFile) {
            const dataUrl = await fileToDataUrl(selectedFile.file);
            fileAttachment = {
                name: selectedFile.file.name,
                type: selectedFile.file.type,
                data: dataUrl
            };
        }
        handleSendMessage(inputValue, fileAttachment);
  };

  // --- Input Handlers ---
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleInputSend();
    }
  };

  const handleEmojiClick = (emoji: string) => {
      setInputValue(prev => prev + emoji);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          let preview = '';
          
          if (file.type.startsWith('image/')) {
              preview = URL.createObjectURL(file);
          }
          
          setSelectedFile({ file, preview });
          e.target.value = ''; // Reset to allow selecting same file again
          setTimeout(() => inputRef.current?.focus(), 50);
      }
  };

  const removeSelectedFile = () => {
      setSelectedFile(null);
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
  };

  // --- Context Menu & Selection Logic ---

  const handleContextMenu = (e: React.MouseEvent, msgId: string) => {
      e.preventDefault();
      setContextMenu({ x: e.clientX, y: e.clientY, msgId });
  };

  const handleAction = (action: 'copy' | 'delete' | 'multi' | 'forward') => {
      if (!contextMenu || !activeContact) return;
      const { msgId } = contextMenu;
      const msg = activeMessages.find(m => m.id === msgId);

      if (action === 'delete') {
          setChatHistory(prev => ({
              ...prev,
              [activeContact.id]: prev[activeContact.id].filter(m => m.id !== msgId)
          }));
      } else if (action === 'copy') {
          if (msg?.text) navigator.clipboard.writeText(msg.text);
      } else if (action === 'multi') {
          setIsSelectionMode(true);
          setSelectedMsgIds(new Set([msgId]));
      } else if (action === 'forward') {
          // Single Forward - Treat as merging 1 message
          if (msg) {
              setMsgsToForward([msg]);
              setShowForwardContactPicker(true);
          }
      }
      setContextMenu(null);
  };

  const toggleSelection = (msgId: string) => {
      const newSet = new Set(selectedMsgIds);
      if (newSet.has(msgId)) newSet.delete(msgId);
      else newSet.add(msgId);
      setSelectedMsgIds(newSet);
  };

  const handleBatchDelete = () => {
      if (!activeContact) return;
      setChatHistory(prev => ({
          ...prev,
          [activeContact.id]: prev[activeContact.id].filter(m => !selectedMsgIds.has(m.id))
      }));
      exitSelectionMode();
  };

  const handleStartForward = () => {
      if (!activeContact) return;
      // Get selected messages sorted by time
      const msgs = activeMessages
          .filter(m => selectedMsgIds.has(m.id))
          .sort((a, b) => a.timestamp - b.timestamp);

      if (msgs.length === 0) return;

      setMsgsToForward(msgs);
      setShowForwardContactPicker(true);
  };

  const handleRealForward = (targetContactId: string) => {
      if (!activeContact || msgsToForward.length === 0) return;

      // 1. Construct the AI-readable text
      const formattedHistory = msgsToForward.map(m => {
          const name = m.sender === 'me' ? userProfile.name : activeContact.name;
          const content = m.file ? `[文件/图片]` : m.text;
          const time = formatTime(m.timestamp);
          return `${name} ${time}\n${content}`;
      }).join('\n\n');

      const title = `${userProfile.name}和${activeContact.name}的聊天记录`;
      const fullText = `[聊天记录] ${title}\n----------------\n${formattedHistory}\n----------------\n`;

      // 2. Construct the UI Record Data
      const previewLines = msgsToForward.slice(0, 4).map(m => {
          const name = m.sender === 'me' ? userProfile.name : activeContact.name;
          const content = m.file ? `[图片/文件]` : m.text;
          // Truncate long content
          const truncated = content.length > 20 ? content.substring(0, 20) + '...' : content;
          return `${name}: ${truncated}`;
      });
      if (msgsToForward.length > 4) {
          previewLines.push(`... (共${msgsToForward.length}条)`);
      }

      const recordData = {
          title,
          preview: previewLines,
          originalMessages: msgsToForward,
          // Snapshot the current user and contact details so they are correct when viewed later
          profiles: {
              me: { name: userProfile.name, avatarUrl: userProfile.avatarUrl },
              them: { name: activeContact.name, avatarUrl: activeContact.avatarUrl }
          }
      };

      // 3. Send
      handleSendMessage(fullText, undefined, recordData, targetContactId);
      
      // 4. Cleanup
      setShowForwardContactPicker(false);
      setMsgsToForward([]);
      exitSelectionMode();
      
      // If we forwarded to someone else, switch to them? Optional. 
      // For now, let's stay, but maybe show a toast.
      if (targetContactId !== activeContactId) {
          // simple switch to see the sent message
          setActiveContactId(targetContactId); 
      }
  };

  const exitSelectionMode = () => {
      setIsSelectionMode(false);
      setSelectedMsgIds(new Set());
  };

  // --- Contact Management (Add / Edit) ---
  const [contactForm, setContactForm] = useState<Partial<Persona>>({
      name: '',
      remark: '',
      gender: Gender.Female,
      personality: '',
      avatarUrl: DEFAULT_AVATARS.AI_FEMALE
  });

  const openAddContact = () => {
      setIsEditing(false);
      setContactForm({ name: '', remark: '', gender: Gender.Female, personality: '', avatarUrl: DEFAULT_AVATARS.AI_FEMALE });
      setShowContactModal(true);
  };

  const openEditContact = () => {
      if (!activeContact) return;
      setIsEditing(true);
      setContactForm({ ...activeContact });
      setShowContactModal(true);
  };

  const handleSaveContact = () => {
     if(!contactForm.name) return;
     
     if (isEditing && activeContact) {
         setContacts(prev => prev.map(c => c.id === activeContact.id ? { ...c, ...contactForm as Persona } : c));
     } else {
         const id = Date.now().toString();
         const contact: Persona = {
             id,
             name: contactForm.name!,
             remark: contactForm.remark,
             gender: contactForm.gender as Gender,
             personality: contactForm.personality || '热情开朗',
             avatarUrl: contactForm.avatarUrl!
         };
         setContacts(prev => [...prev, contact]);
         setChatHistory(prev => ({...prev, [id]: []}));
         setActiveContactId(id);
         setActiveTab('chat');
     }
     setShowContactModal(false);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if(e.target.files && e.target.files[0]) {
          const url = URL.createObjectURL(e.target.files[0]);
          setContactForm(prev => ({...prev, avatarUrl: url}));
      }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-200 p-4 md:p-10 font-sans">
      
      {/* Context Menu */}
      {contextMenu && (
        <div 
            ref={contextMenuRef}
            className="fixed bg-white shadow-xl rounded-md py-1 z-50 text-sm min-w-[120px] animate-fade-in border border-gray-100"
            style={{ top: contextMenu.y, left: contextMenu.x }}
        >
            <button onClick={() => handleAction('copy')} className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2">
                <Icons.Copy /> 复制
            </button>
            <button onClick={() => handleAction('forward')} className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2">
                <Icons.Forward /> 转发
            </button>
            <button onClick={() => handleAction('multi')} className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2 border-t border-gray-100 mt-1">
                 多选
            </button>
            <button onClick={() => handleAction('delete')} className="w-full text-left px-4 py-2 hover:bg-gray-100 text-red-500 flex items-center gap-2">
                <Icons.Trash /> 删除
            </button>
        </div>
      )}

      {/* Record Detail Modal (View Chat History) */}
      {viewingRecord && (
          <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
             <div className="bg-[#f5f5f5] w-[400px] h-[600px] rounded-lg shadow-2xl flex flex-col overflow-hidden animate-fade-in">
                 <div className="h-12 border-b border-gray-200 flex items-center justify-between px-4 bg-[#f5f5f5]">
                     <span className="font-medium text-black truncate">{viewingRecord.title}</span>
                     <button onClick={() => setViewingRecord(null)} className="text-gray-500 hover:text-black">✕</button>
                 </div>
                 <div className="flex-1 overflow-y-auto p-4 space-y-4">
                     {viewingRecord.originalMessages.map(m => {
                         // Use the snapshot profile from the record, not the current contact
                         const profile = m.sender === 'me' ? viewingRecord.profiles.me : viewingRecord.profiles.them;
                         
                         return (
                            <div key={m.id} className="flex gap-3">
                                <img 
                                    src={profile.avatarUrl} 
                                    className="w-8 h-8 rounded bg-gray-300 object-cover" 
                                    alt="avatar"
                                />
                                <div className="flex flex-col">
                                    <span className="text-xs text-gray-400 mb-1">
                                        {profile.name} {formatTime(m.timestamp)}
                                    </span>
                                    <div className="bg-white p-2 rounded text-sm shadow-sm whitespace-pre-wrap">
                                        {m.file ? (
                                            m.file.type.startsWith('image/') 
                                            ? <img src={m.file.data} className="max-w-[150px] rounded" alt="img" />
                                            : `[文件] ${m.file.name}`
                                        ) : m.text}
                                    </div>
                                </div>
                            </div>
                         );
                     })}
                 </div>
             </div>
          </div>
      )}

      {/* Forward Contact Picker Modal */}
      {showForwardContactPicker && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40 backdrop-blur-sm">
              <div className="bg-white rounded-lg shadow-xl w-80 overflow-hidden animate-fade-in">
                  <div className="bg-[#f5f5f5] px-4 py-3 border-b flex justify-between items-center">
                      <h3 className="text-sm font-medium">选择发送对象</h3>
                      <button onClick={() => setShowForwardContactPicker(false)} className="text-gray-500 hover:text-black">✕</button>
                  </div>
                  <div className="p-2 h-80 overflow-y-auto">
                      <div className="text-xs text-gray-400 px-2 py-1">最近聊天</div>
                      {contacts.map(contact => (
                          <div 
                              key={contact.id}
                              onClick={() => handleRealForward(contact.id)}
                              className="flex items-center gap-3 p-2 hover:bg-gray-100 rounded cursor-pointer"
                          >
                              <img src={contact.avatarUrl} className="w-9 h-9 rounded object-cover" alt="avatar"/>
                              <span className="text-sm">{contact.remark || contact.name}</span>
                          </div>
                      ))}
                      {contacts.length === 0 && (
                          <div className="text-center text-gray-400 py-10 text-sm">暂无联系人</div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {/* Contact Modal (Add/Edit) */}
      {showContactModal && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40 backdrop-blur-sm">
              <div className="bg-white rounded-lg shadow-xl w-96 overflow-hidden animate-fade-in">
                  <div className="bg-[#f5f5f5] px-4 py-3 border-b flex justify-between items-center">
                      <h3 className="text-sm font-medium">{isEditing ? '详细资料 / 编辑' : '添加朋友 / 新建人设'}</h3>
                      <button onClick={() => setShowContactModal(false)} className="text-gray-500 hover:text-black">✕</button>
                  </div>
                  <div className="p-5 space-y-4">
                      <div className="flex justify-center">
                          <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                              <img src={contactForm.avatarUrl} className="w-20 h-20 rounded-lg object-cover bg-gray-100" alt="avatar"/>
                              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 text-white text-xs opacity-0 group-hover:opacity-100 rounded-lg transition-opacity">
                                  {isEditing ? '修改头像' : '上传头像'}
                              </div>
                              <input type="file" ref={fileInputRef} onChange={handleAvatarUpload} accept="image/*" className="hidden" />
                          </div>
                      </div>
                      
                      <div>
                          <label className="text-xs text-gray-500 block mb-1">昵称</label>
                          <input 
                            className="w-full border-b border-gray-200 py-1 px-1 text-sm outline-none focus:border-[#07c160]"
                            placeholder="例如: DeepSeek"
                            value={contactForm.name}
                            onChange={e => setContactForm({...contactForm, name: e.target.value})}
                          />
                      </div>
                      <div>
                          <label className="text-xs text-gray-500 block mb-1">备注</label>
                          <input 
                            className="w-full border-b border-gray-200 py-1 px-1 text-sm outline-none focus:border-[#07c160]"
                            placeholder="例如: AI助手"
                            value={contactForm.remark}
                            onChange={e => setContactForm({...contactForm, remark: e.target.value})}
                          />
                      </div>
                      
                      <div>
                          <label className="text-xs text-gray-500 block mb-1">性别</label>
                          <div className="flex gap-4 text-sm text-gray-600">
                              {Object.values(Gender).map(g => (
                                  <label key={g} className="flex items-center cursor-pointer">
                                      <input type="radio" name="gender" checked={contactForm.gender === g} onChange={() => setContactForm({...contactForm, gender: g})} className="mr-1 accent-[#07c160]" />
                                      {g}
                                  </label>
                              ))}
                          </div>
                      </div>
                      
                      <div>
                          <label className="text-xs text-gray-500 block mb-1">性格与人设描述</label>
                          <textarea 
                            className="w-full border border-gray-200 rounded p-2 text-sm h-24 resize-none outline-none focus:border-[#07c160] bg-gray-50"
                            placeholder="描述AI的说话语气、身份背景等..."
                            value={contactForm.personality}
                            onChange={e => setContactForm({...contactForm, personality: e.target.value})}
                          />
                      </div>
                      <button 
                        onClick={handleSaveContact}
                        disabled={!contactForm.name}
                        className="w-full bg-[#07c160] text-white py-2 rounded text-sm font-medium hover:bg-[#06ad56] disabled:opacity-50"
                      >
                          {isEditing ? '保存修改' : '添加到通讯录'}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Main Container */}
      <div className="flex w-full max-w-[1000px] h-[85vh] bg-white rounded-lg overflow-hidden shadow-2xl relative">
        
        {/* 1. Sidebar */}
        <div className="w-[60px] bg-[#2e2e2e] flex flex-col items-center py-4 justify-between shrink-0 z-20">
          <div className="flex flex-col items-center gap-6">
            <img 
              src={userProfile.avatarUrl} 
              alt="My Avatar" 
              className="w-9 h-9 rounded-lg mb-2 cursor-pointer hover:opacity-80 transition-opacity object-cover bg-gray-600" 
              onClick={() => setActiveTab('settings')}
              title="点击修改个人信息"
            />
            
            <button 
              onClick={() => setActiveTab('chat')}
              className={`p-1 ${activeTab === 'chat' ? 'text-[#07c160]' : 'text-[#979797] hover:text-white'}`}
            >
              <Icons.Chat />
            </button>
            <button 
              onClick={() => { setActiveTab('contacts'); }}
              className={`p-1 ${activeTab === 'contacts' ? 'text-[#07c160]' : 'text-[#979797] hover:text-white'}`}
            >
              <Icons.Contacts />
            </button>
          </div>

          <div className="flex flex-col gap-4 mb-2">
            <button 
              onClick={() => setActiveTab('settings')}
              className={`p-1 ${activeTab === 'settings' ? 'text-[#07c160]' : 'text-[#979797] hover:text-white'}`}
              title="设置"
            >
              <Icons.Settings />
            </button>
          </div>
        </div>

        {/* 2. List Column */}
        {activeTab === 'chat' && (
          <div className="w-[250px] bg-[#e6e5e5] border-r border-[#d6d6d6] flex flex-col shrink-0">
            <div className="h-16 flex items-center px-3 bg-[#f7f7f7] shrink-0">
               <div className="flex items-center bg-[#e2e2e2] rounded w-full h-7 px-2 text-xs gap-2">
                  <span className="text-gray-500"><Icons.Search /></span>
                  <input type="text" placeholder="搜索" className="bg-transparent outline-none w-full text-gray-600 placeholder-gray-500" />
               </div>
               <button 
                onClick={openAddContact}
                className="ml-2 w-7 h-7 bg-[#e2e2e2] rounded flex items-center justify-center text-gray-600 hover:bg-[#d2d2d2] transition-colors"
               >
                 <Icons.Plus />
               </button>
            </div>

            <div className="flex-1 overflow-y-auto">
                {contacts.length === 0 && (
                   <div className="text-center text-gray-400 text-xs mt-10">
                      暂无消息
                   </div>
                )}
                {contacts.map(contact => {
                    const msgs = chatHistory[contact.id] || [];
                    const lastMsg = msgs[msgs.length - 1];
                    const isActive = activeContactId === contact.id;
                    
                    let lastContent = '';
                    if (lastMsg) {
                        if (lastMsg.recordData) lastContent = '[聊天记录]';
                        else if (lastMsg.file) lastContent = lastMsg.file.type.startsWith('image/') ? '[图片]' : '[文件]';
                        else lastContent = lastMsg.text;
                    }

                    return (
                        <div 
                            key={contact.id}
                            onClick={() => setActiveContactId(contact.id)}
                            className={`p-3 flex gap-3 cursor-pointer transition-colors ${isActive ? 'bg-[#c6c6c6]' : 'hover:bg-[#dcdcdc]'}`}
                        >
                            <img src={contact.avatarUrl} className="w-10 h-10 rounded object-cover" alt="avatar" />
                            <div className="flex-1 min-w-0 flex flex-col justify-between">
                                <div className="flex justify-between items-center">
                                    <span className="text-sm font-medium text-black truncate">
                                        {contact.remark || contact.name}
                                    </span>
                                    {lastMsg && (
                                        <span className="text-xs text-gray-500">{formatTime(lastMsg.timestamp)}</span>
                                    )}
                                </div>
                                <p className="text-xs text-gray-500 truncate">
                                  {isActive && isTyping ? '[对方正在输入...]' : lastContent}
                                </p>
                            </div>
                        </div>
                    );
                })}
            </div>
          </div>
        )}

        {activeTab === 'contacts' && (
             <div className="w-[250px] bg-[#e6e5e5] border-r border-[#d6d6d6] flex flex-col shrink-0">
                 <div className="h-16 flex items-center px-3 bg-[#f7f7f7] shrink-0">
                    <span className="text-gray-500 text-sm">通讯录</span>
                    <button 
                        onClick={openAddContact}
                        className="ml-auto w-7 h-7 bg-[#e2e2e2] rounded flex items-center justify-center text-gray-600 hover:bg-[#d2d2d2]"
                    >
                        <Icons.Plus />
                    </button>
                 </div>
                 <div className="flex-1 overflow-y-auto">
                     <div className="px-3 py-1 text-xs text-gray-500">新的朋友</div>
                     <div 
                        onClick={openAddContact}
                        className="bg-white p-3 flex items-center gap-3 cursor-pointer hover:bg-gray-50 border-b border-gray-100"
                    >
                         <div className="w-9 h-9 bg-orange-400 rounded flex items-center justify-center text-white"><Icons.Plus /></div>
                         <span className="text-sm">新建 AI 联系人</span>
                     </div>
                     
                     <div className="px-3 py-1 text-xs text-gray-500 mt-2">联系人 ({contacts.length})</div>
                     {contacts.map(contact => (
                         <div 
                            key={contact.id}
                            onClick={() => { setActiveContactId(contact.id); setActiveTab('chat'); }}
                            className="p-2.5 flex items-center gap-3 cursor-pointer hover:bg-[#dcdcdc] border-b border-gray-200/50"
                         >
                             <img src={contact.avatarUrl} className="w-9 h-9 rounded object-cover" alt="avatar" />
                             <span className="text-sm text-black">{contact.remark || contact.name}</span>
                         </div>
                     ))}
                 </div>
             </div>
        )}

        {/* 3. Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#f5f5f5]">
            {activeTab === 'settings' ? (
                <SettingsPanel 
                  settings={settings} 
                  setSettings={setSettings}
                  userProfile={userProfile}
                  setUserProfile={setUserProfile}
                  contacts={contacts}
                  setContacts={setContacts}
                  chatHistory={chatHistory}
                  setChatHistory={setChatHistory}
                  onClose={() => setActiveTab('chat')}
                />
            ) : (activeTab === 'chat' || activeTab === 'contacts') ? (
                activeContact ? (
                    <>
                    {/* Chat Header */}
                    <div className="h-16 border-b border-[#e7e7e7] flex items-center justify-between px-5 shrink-0 select-none bg-[#f5f5f5]">
                        <div className="flex flex-col">
                            <h2 className="text-lg font-medium text-black cursor-default flex items-center gap-2">
                                {activeContact.remark || activeContact.name}
                                {activeContact.remark && <span className="text-xs text-gray-400">({activeContact.name})</span>}
                            </h2>
                        </div>
                        <div 
                          className="text-gray-500 hover:text-black cursor-pointer p-2 rounded hover:bg-gray-200 transition-colors"
                          onClick={openEditContact}
                        >
                            <div className="w-5 h-1 bg-gray-400 rounded-full mb-1"></div>
                            <div className="w-5 h-1 bg-gray-400 rounded-full mb-1"></div>
                            <div className="w-5 h-1 bg-gray-400 rounded-full"></div>
                        </div>
                    </div>

                    {/* Messages Area */}
                    <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4" onClick={() => setShowEmojiPicker(false)}>
                        {activeMessages.length === 0 && (
                            <div className="text-center text-gray-300 text-xs py-10">
                                可以在右上角 "..." 设置该联系人的性格
                            </div>
                        )}
                        {activeMessages.map((msg) => (
                            <div 
                                key={msg.id} 
                                className={`flex gap-3 relative group ${msg.sender === 'me' ? 'flex-row-reverse' : ''}`}
                                onContextMenu={(e) => !isSelectionMode && handleContextMenu(e, msg.id)}
                                onClick={() => isSelectionMode && toggleSelection(msg.id)}
                            >
                                {/* Selection Checkbox */}
                                {isSelectionMode && (
                                    <div className="flex items-center px-2">
                                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                                            selectedMsgIds.has(msg.id) 
                                            ? 'bg-[#07c160] border-[#07c160]' 
                                            : 'bg-transparent border-gray-300'
                                        }`}>
                                            {selectedMsgIds.has(msg.id) && (
                                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
                                                    <polyline points="20 6 9 17 4 12"></polyline>
                                                </svg>
                                            )}
                                        </div>
                                    </div>
                                )}

                                <img 
                                  src={msg.sender === 'me' ? userProfile.avatarUrl : activeContact.avatarUrl} 
                                  className="w-9 h-9 rounded bg-gray-200 select-none cursor-pointer object-cover" 
                                  alt={msg.sender} 
                                />
                                
                                <div className={`max-w-[70%] flex flex-col ${msg.sender === 'me' ? 'items-end' : 'items-start'}`}>
                                    {/* Record Card (Chat History) */}
                                    {msg.recordData ? (
                                        <div 
                                            onClick={() => setViewingRecord(msg.recordData!)}
                                            className="bg-white rounded-lg border border-gray-200 w-64 overflow-hidden cursor-pointer hover:bg-gray-50 text-left shadow-sm"
                                        >
                                            <div className="px-3 py-2 text-sm font-medium text-black truncate border-b border-gray-100">
                                                {msg.recordData.title}
                                            </div>
                                            <div className="px-3 py-2 text-xs text-gray-500 space-y-1">
                                                {msg.recordData.preview.map((line, i) => (
                                                    <div key={i} className="truncate">{line}</div>
                                                ))}
                                            </div>
                                            <div className="px-3 py-1.5 border-t border-gray-100 text-[10px] text-gray-400">
                                                聊天记录
                                            </div>
                                        </div>
                                    ) : (
                                        /* File or Text Bubble */
                                        <>
                                            {msg.file && (
                                                <div className="mb-1">
                                                    {msg.file.type.startsWith('image/') ? (
                                                        <img src={msg.file.data} className="max-w-[200px] max-h-[300px] rounded-lg border border-gray-200 shadow-sm" alt="attachment" />
                                                    ) : (
                                                        <div className="bg-white p-3 rounded shadow-sm border border-gray-100 flex items-center gap-3 min-w-[200px]">
                                                            <div className="text-orange-400"><Icons.FileGeneric /></div>
                                                            <div className="overflow-hidden">
                                                                <div className="text-sm truncate">{msg.file.name}</div>
                                                                <div className="text-xs text-gray-400">文件</div>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            )}

                                            {(msg.text && !msg.recordData && (!msg.file || msg.text !== '')) && (
                                                <div 
                                                    className={`px-2.5 py-2 rounded text-[14px] leading-6 relative break-words shadow-sm whitespace-pre-wrap
                                                    ${msg.sender === 'me' 
                                                        ? 'bg-[#95ec69] text-black' 
                                                        : 'bg-white text-black'
                                                    } ${isSelectionMode ? 'cursor-pointer' : 'cursor-text select-text'}`}
                                                >
                                                    {msg.text}
                                                </div>
                                            )}
                                        </>
                                    )}
                                </div>
                            </div>
                        ))}
                        {isTyping && (
                             <div className="flex gap-3">
                                 <img src={activeContact.avatarUrl} className="w-9 h-9 rounded bg-gray-200 object-cover" alt="ai" />
                                 <div className="bg-white px-3 py-2 rounded text-sm text-gray-400 shadow-sm">
                                     正在输入...
                                 </div>
                             </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Chat Input Area (Replaced by Selection Toolbar if Active) */}
                    {isSelectionMode ? (
                        <div className="h-[180px] border-t border-[#e7e7e7] bg-[#f5f5f5] flex items-center justify-center flex-col animate-fade-in relative z-10 select-none">
                             <div className="absolute top-4 right-4">
                                  <button onClick={exitSelectionMode} className="p-2 bg-gray-200 hover:bg-gray-300 rounded-full text-gray-600">
                                     <Icons.Close />
                                  </button>
                             </div>
                             
                             <div className="flex gap-16 mt-4">
                                 <div 
                                     onClick={() => selectedMsgIds.size > 0 && handleStartForward()}
                                     className={`flex flex-col items-center gap-2 cursor-pointer transition-opacity ${selectedMsgIds.size === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:opacity-80'}`}
                                 >
                                     <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center text-gray-700 shadow-sm">
                                         <Icons.Forward />
                                     </div>
                                     <span className="text-xs text-gray-500">转发</span>
                                 </div>

                                 <div 
                                     onClick={() => selectedMsgIds.size > 0 && handleBatchDelete()}
                                     className={`flex flex-col items-center gap-2 cursor-pointer transition-opacity ${selectedMsgIds.size === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:opacity-80'}`}
                                 >
                                     <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center text-red-500 shadow-sm">
                                         <Icons.Trash />
                                     </div>
                                     <span className="text-xs text-gray-500">删除</span>
                                 </div>
                             </div>
                        </div>
                    ) : (
                        <div className="h-[180px] border-t border-[#e7e7e7] flex flex-col bg-[#f5f5f5] relative">
                            
                            {/* File Preview Chip */}
                            {selectedFile && (
                                <div className="absolute top-[-50px] left-4 z-10 bg-white shadow-lg p-2 rounded-lg border border-gray-200 flex items-center gap-3 animate-fade-in">
                                    {selectedFile.preview ? (
                                        <img src={selectedFile.preview} className="w-8 h-8 rounded object-cover" alt="prev"/>
                                    ) : (
                                        <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center text-gray-500"><Icons.Folder /></div>
                                    )}
                                    <div className="text-xs max-w-[150px] truncate text-gray-600">{selectedFile.file.name}</div>
                                    <button onClick={removeSelectedFile} className="text-gray-400 hover:text-red-500 p-1"><Icons.Close /></button>
                                </div>
                            )}

                            {/* Emoji Picker Popup */}
                            {showEmojiPicker && (
                                <div className="absolute bottom-[145px] left-2 bg-white shadow-2xl rounded-lg border border-gray-200 p-2 w-[320px] h-[200px] overflow-y-auto z-50 grid grid-cols-8 gap-1">
                                    {EMOJI_LIST.map((emoji, idx) => (
                                        <button 
                                            key={idx} 
                                            className="text-xl hover:bg-gray-100 rounded p-1"
                                            onClick={() => handleEmojiClick(emoji)}
                                        >
                                            {emoji}
                                        </button>
                                    ))}
                                </div>
                            )}

                            {/* Toolbar */}
                            <div className="h-10 flex items-center px-4 gap-4 text-[#7d7d7d]">
                                <button 
                                    className={`hover:text-black ${showEmojiPicker ? 'text-[#07c160]' : ''}`} 
                                    title="表情"
                                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                                >
                                    <Icons.Emoji />
                                </button>
                                <button 
                                    className="hover:text-black" 
                                    title="发送文件"
                                    onClick={() => chatFileRef.current?.click()}
                                >
                                    <Icons.Folder />
                                </button>
                                <input 
                                    type="file" 
                                    ref={chatFileRef} 
                                    className="hidden" 
                                    onChange={handleFileSelect} 
                                />
                            </div>

                            {/* Textarea */}
                            <textarea 
                                ref={inputRef}
                                className="flex-1 bg-transparent px-5 py-0 resize-none outline-none text-[14px] leading-6 text-black placeholder-gray-400 scrollbar-none"
                                value={inputValue}
                                onChange={(e) => setInputValue(e.target.value)}
                                onKeyDown={handleKeyDown}
                            />

                            {/* Footer / Send Button */}
                            <div className="h-12 flex justify-end items-center px-5 relative">
                                <div className="text-xs text-gray-400 absolute left-5">
                                    按下 Ctrl+Enter 换行
                                </div>
                                <button 
                                    onClick={handleInputSend}
                                    disabled={!inputValue.trim() && !selectedFile}
                                    className={`px-6 py-1.5 rounded text-sm transition-colors ${
                                        (inputValue.trim() || selectedFile)
                                        ? 'bg-[#e9e9e9] text-[#07c160] hover:bg-[#d2d2d2]' 
                                        : 'bg-[#e9e9e9] text-[#e3e3e3] cursor-default'
                                    }`}
                                >
                                    发送(S)
                                </button>
                            </div>
                        </div>
                    )}
                    </>
                ) : (
                    <div className="flex-1 flex items-center justify-center text-gray-400 flex-col">
                         <div className="text-6xl mb-4 opacity-20 select-none">👋</div>
                         <p className="select-none">暂无联系人</p>
                         <button onClick={openAddContact} className="text-[#07c160] mt-2 hover:underline">
                             + 添加新的 AI 朋友
                         </button>
                    </div>
                )
            ) : null}
        </div>
      </div>
    </div>
  );
}

export default App;
