
import React, { useRef, useState } from 'react';
import { AppSettings, UserProfile, Persona, Message } from '../types';

interface SettingsPanelProps {
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  userProfile: UserProfile;
  setUserProfile: (u: UserProfile) => void;
  contacts: Persona[];
  setContacts: (c: Persona[]) => void;
  chatHistory: Record<string, Message[]>;
  setChatHistory: (h: Record<string, Message[]>) => void;
  onClose: () => void;
}

// Helper: Convert Base64 DataURL to Blob
const dataURLtoBlob = (dataurl: string): Blob | null => {
    try {
        const arr = dataurl.split(',');
        if (arr.length < 2) return null; // Not a data URL
        const mimeMatch = arr[0].match(/:(.*?);/);
        if (!mimeMatch) return null;
        
        const mime = mimeMatch[1];
        const bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], { type: mime });
    } catch (e) {
        console.error("Failed to convert data URL to blob", e);
        return null;
    }
};

// Helper: Fetch remote URL (like picsum) and convert to Blob
const fetchUrlToBlob = async (url: string): Promise<Blob | null> => {
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.blob();
    } catch (error) {
        console.warn("Failed to fetch image for saving:", url, error);
        return null;
    }
};

const makeSafeFileName = (name: string): string => {
    const base = (name || '').replace(/[\\/:*?"<>|]/g, '').trim();
    return base || 'unknown';
};

const SettingsPanel: React.FC<SettingsPanelProps> = ({
  settings,
  setSettings,
  userProfile,
  setUserProfile,
  contacts,
  setContacts,
  chatHistory,
  setChatHistory,
  onClose
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const [syncStatus, setSyncStatus] = useState<string>('');
  const [lastSyncTime, setLastSyncTime] = useState<string>('');

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => {
          if(ev.target?.result) {
              setUserProfile({ ...userProfile, avatarUrl: ev.target.result as string });
          }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  // --- Folder Sync Logic ---
  
  const handleLoadFromFolder = () => {
    setSyncStatus('请选择 F:\\聊天 文件夹...');
    folderInputRef.current?.click();
  };

  const handleFolderSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setSyncStatus('正在解析文件...');
    
    const fileList = Array.from(files);
    
    // Maps to store loaded data temporarily
    let loadedProfile: any = null;
    let loadedSettings: any = null;
    let loadedContacts: any = null;
    let loadedHistory: any = null;

    // Map: Filename (e.g., "me.png") -> Blob URL (blob:http://...)
    const avatarMap = new Map<string, string>();

    // Helper to read file as text
    const readFileText = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsText(file);
        });
    };

    try {
        // 1. First Pass: Load all Avatars into Map and find JSON files
        for (const file of fileList) {
            const path = file.webkitRelativePath || file.name;
            // Normalize path separators
            const normalizedPath = path.replace(/\\/g, '/');

            // Handle Avatars (Look inside "头像" folder)
            if (normalizedPath.includes('/头像/') || normalizedPath.includes('\\头像\\')) {
                const fileName = file.name; // e.g., "me.png"
                const blobUrl = URL.createObjectURL(file);
                avatarMap.set(fileName, blobUrl);
            }
        }

        // 2. Second Pass: Parse JSON files
        for (const file of fileList) {
             const path = file.webkitRelativePath || file.name;
             
             if (path.includes('全局信息') && path.includes('user_profile.json')) {
                const text = await readFileText(file);
                loadedProfile = JSON.parse(text);
             }
             else if (path.includes('全局信息') && path.includes('app_settings.json')) {
                const text = await readFileText(file);
                loadedSettings = JSON.parse(text);
             }
             else if (path.includes('聊天对象') && path.includes('contacts.json')) {
                const text = await readFileText(file);
                loadedContacts = JSON.parse(text);
             }
             else if (path.includes('聊天记录') && path.includes('history.json')) {
                const text = await readFileText(file);
                loadedHistory = JSON.parse(text);
             }
        }

        const summary = [];

        // 3. Reconstruct Data with Avatar Images
        if (loadedProfile) {
            // If avatarUrl is a simple filename (no slash, has extension), look it up
            const filename = loadedProfile.avatarUrl;
            if (filename && !filename.startsWith('data:') && !filename.startsWith('http')) {
                if (avatarMap.has(filename)) {
                    loadedProfile.avatarUrl = avatarMap.get(filename);
                }
            }
            setUserProfile(loadedProfile);
            localStorage.setItem('wechat_sim_profile', JSON.stringify(loadedProfile));
            summary.push('全局信息(含头像)');
        }

        if (loadedContacts && Array.isArray(loadedContacts)) {
            const updatedContacts = loadedContacts.map((c: any) => {
                const filename = c.avatarUrl;
                if (filename && !filename.startsWith('data:') && !filename.startsWith('http')) {
                    if (avatarMap.has(filename)) {
                        return { ...c, avatarUrl: avatarMap.get(filename) };
                    }
                }
                return c;
            });
            setContacts(updatedContacts);
            localStorage.setItem('wechat_sim_contacts', JSON.stringify(updatedContacts));
            summary.push('聊天对象');
        }

        if (loadedSettings) {
            setSettings(loadedSettings);
            localStorage.setItem('wechat_sim_settings', JSON.stringify(loadedSettings));
            summary.push('配置');
        }

        if (loadedHistory) {
            setChatHistory(loadedHistory);
            localStorage.setItem('wechat_sim_history', JSON.stringify(loadedHistory));
            summary.push('聊天记录');
        }

        if (summary.length > 0) {
            setSyncStatus(`✅ 读取成功: ${summary.join(', ')}`);
            setLastSyncTime(new Date().toLocaleTimeString());
            alert(`读取完成！\n已更新: ${summary.join(', ')}`);
        } else {
            setSyncStatus('⚠️ 未在文件夹中找到有效的数据文件');
            alert('未找到有效数据。请选择包含“全局信息”、“聊天对象”等文件夹的根目录 (F:\\聊天)。');
        }

    } catch (err: any) {
        console.error(err);
        setSyncStatus(`❌ 读取失败: ${err.message}`);
    }
    
    if (folderInputRef.current) folderInputRef.current.value = '';
  };

  const handleSaveToFolder = async () => {
      setSyncStatus('正在尝试保存...');
      
      try {
          // @ts-ignore
          if (typeof window.showDirectoryPicker !== 'function') {
              throw new Error('FileSystemAccessAPI_NotSupported');
          }

          // @ts-ignore
          const dirHandle = await window.showDirectoryPicker({
            id: 'wechat-sim-data',
            mode: 'readwrite',
            startIn: 'documents'
          });

          // Create Directories
          const globalDir = await dirHandle.getDirectoryHandle('全局信息', { create: true });
          const contactsDir = await dirHandle.getDirectoryHandle('聊天对象', { create: true });
          const historyDir = await dirHandle.getDirectoryHandle('聊天记录', { create: true });
          const avatarsDir = await dirHandle.getDirectoryHandle('头像', { create: true }); // New Avatars Directory

          // --- 1. Save User Profile & Avatar ---
          const profileToSave = { ...userProfile };
          
          let userAvatarBlob: Blob | null = null;
          if (userProfile.avatarUrl.startsWith('data:')) {
              userAvatarBlob = dataURLtoBlob(userProfile.avatarUrl);
          } else if (userProfile.avatarUrl.startsWith('http')) {
              userAvatarBlob = await fetchUrlToBlob(userProfile.avatarUrl);
          } else if (userProfile.avatarUrl.startsWith('blob:')) {
              userAvatarBlob = await fetchUrlToBlob(userProfile.avatarUrl);
          }

          if (userAvatarBlob) {
              const fileName = `me.jpg`;
              const fileHandle = await avatarsDir.getFileHandle(fileName, { create: true });
              const writable = await fileHandle.createWritable();
              await writable.write(userAvatarBlob);
              await writable.close();
              
              // Update JSON to reference the file
              profileToSave.avatarUrl = fileName; 
          }

          const profileHandle = await globalDir.getFileHandle('user_profile.json', { create: true });
          const profileWritable = await profileHandle.createWritable();
          await profileWritable.write(JSON.stringify(profileToSave, null, 2));
          await profileWritable.close();

          const settingsHandle = await globalDir.getFileHandle('app_settings.json', { create: true });
          const settingsWritable = await settingsHandle.createWritable();
          await settingsWritable.write(JSON.stringify(settings, null, 2));
          await settingsWritable.close();

          // --- 2. Save Contacts & Avatars ---
          const contactsToSave = await Promise.all(contacts.map(async (c) => {
              const contactCopy = { ...c };
              
              let contactAvatarBlob: Blob | null = null;
              if (c.avatarUrl.startsWith('data:')) {
                  contactAvatarBlob = dataURLtoBlob(c.avatarUrl);
              } else if (c.avatarUrl.startsWith('http')) {
                  contactAvatarBlob = await fetchUrlToBlob(c.avatarUrl);
              } else if (c.avatarUrl.startsWith('blob:')) {
                  contactAvatarBlob = await fetchUrlToBlob(c.avatarUrl);
              }

              if (contactAvatarBlob) {
                  const baseName = makeSafeFileName(c.remark || c.name || c.id);
                  const fileName = `${baseName}.jpg`;
                  const fileHandle = await avatarsDir.getFileHandle(fileName, { create: true });
                  const writable = await fileHandle.createWritable();
                  await writable.write(contactAvatarBlob);
                  await writable.close();

                  contactCopy.avatarUrl = fileName;
              }
              return contactCopy;
          }));

          const contactsHandle = await contactsDir.getFileHandle('contacts.json', { create: true });
          const contactsWritable = await contactsHandle.createWritable();
          await contactsWritable.write(JSON.stringify(contactsToSave, null, 2));
          await contactsWritable.close();

          // --- 3. Save History ---
          // Note: Chat history images (Message.file) are complex to extract due to nesting.
          // For now, we save history as is (containing base64) or basic text. 
          // The request focused on "头像信息".
          const historyHandle = await historyDir.getFileHandle('history.json', { create: true });
          const historyWritable = await historyHandle.createWritable();
          await historyWritable.write(JSON.stringify(chatHistory, null, 2));
          await historyWritable.close();

          setSyncStatus('✅ 保存成功 (头像已独立存储)');
          setLastSyncTime(new Date().toLocaleTimeString());
          alert(`保存成功！\n- 头像文件已存入 "F:\\聊天\\头像"\n- JSON 文件已更新引用`);

      } catch (err: any) {
          const isSecurityError = err.name === 'SecurityError' || (err.message && err.message.includes('Cross origin'));
          const isNotSupported = err.message === 'FileSystemAccessAPI_NotSupported';
          const isAbort = err.name === 'AbortError';

          if (isAbort) {
               setSyncStatus('操作已取消');
               return;
          }
          
          // Fallback: Download JSON
          if (isSecurityError || isNotSupported) {
               console.warn("Direct save not allowed, falling back to download.");
               setSyncStatus('⚠️ 正在下载备份文件 (浏览器限制直接写入)');
               
               // In fallback mode, we CANNOT split files easily to disk.
               // We must save the original data with Base64 intact so the user doesn't lose data.
               const backupData = {
                   userProfile,
                   settings,
                   contacts,
                   chatHistory,
                   readme: "注意：由于浏览器安全限制无法直接写入文件夹，此备份包含内嵌的图片数据(Base64)，而非独立图片文件。"
               };
               
               const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
               const url = URL.createObjectURL(blob);
               const a = document.createElement('a');
               a.href = url;
               a.download = 'wechat_data_backup.json';
               document.body.appendChild(a);
               a.click();
               document.body.removeChild(a);
               URL.revokeObjectURL(url);
               
               alert('由于浏览器安全限制（运行在沙盒/Iframe中），无法直接写入 F:\\聊天。\n\n已为您自动下载备份文件 (包含所有图片数据)。');
          } else {
               console.error("Save failed:", err);
               setSyncStatus(`❌ 保存失败: ${err.message}`);
          }
      }
  };

  return (
    <div className="flex flex-col h-full bg-[#f5f5f5] text-sm text-gray-700 animate-fade-in">
      <div className="h-14 border-b border-[#e7e7e7] flex items-center justify-between px-4 bg-[#f5f5f5]">
        <h2 className="text-lg font-medium text-black">全局设置</h2>
        <button onClick={onClose} className="text-gray-500 hover:text-black">关闭</button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-8">
        
        {/* User Profile Section */}
        <section>
          <h3 className="text-xs font-semibold text-gray-400 mb-3 uppercase tracking-wider">个人信息 (我)</h3>
          <div className="bg-white p-4 rounded-lg shadow-sm flex items-center space-x-4">
             <div 
               className="relative group cursor-pointer"
               onClick={() => fileInputRef.current?.click()}
             >
                <img src={userProfile.avatarUrl} alt="Me" className="w-16 h-16 rounded-lg object-cover bg-gray-200" />
                <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 rounded-lg transition-opacity text-xs">
                  更换
                </div>
                <input type="file" ref={fileInputRef} onChange={handleAvatarChange} accept="image/*" className="hidden" />
             </div>
             <div className="flex-1">
               <label className="block text-xs text-gray-500 mb-1">我的昵称</label>
               <input 
                  type="text" 
                  value={userProfile.name}
                  onChange={(e) => setUserProfile({...userProfile, name: e.target.value})}
                  className="w-full border-b border-gray-200 focus:border-[#95ec69] outline-none py-1 transition-colors bg-transparent"
               />
             </div>
          </div>
        </section>

        {/* AI Configuration */}
        <section>
          <h3 className="text-xs font-semibold text-gray-400 mb-3 uppercase tracking-wider">AI 模型源</h3>
          <div className="bg-white p-4 rounded-lg shadow-sm space-y-5">
            
            {/* Provider Selector */}
            <div className="flex space-x-2 bg-gray-100 p-1 rounded-lg">
              {(['siliconflow', 'gemini', 'local'] as const).map(p => (
                <button
                  key={p}
                  onClick={() => setSettings({...settings, provider: p})}
                  className={`flex-1 py-1.5 text-xs rounded-md transition-all ${
                    settings.provider === p ? 'bg-white shadow text-[#07c160] font-medium' : 'text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  {p === 'siliconflow' ? '硅基流动' : p === 'gemini' ? 'Gemini API' : '本地模型'}
                </button>
              ))}
            </div>

            {/* SiliconFlow Config */}
            {settings.provider === 'siliconflow' && (
              <div className="space-y-3 animate-fade-in">
                 <div>
                  <label className="block text-xs text-gray-500 mb-1">API Key (sk-...)</label>
                  <input 
                    type="password"
                    value={settings.siliconFlowApiKey}
                    onChange={(e) => setSettings({...settings, siliconFlowApiKey: e.target.value})}
                    placeholder="请输入硅基流动 API Key"
                    className="w-full bg-gray-50 border border-gray-200 rounded p-2 text-xs font-mono outline-none focus:border-[#07c160]"
                  />
                 </div>
                 <div>
                  <label className="block text-xs text-gray-500 mb-1">对话模型 (默认)</label>
                  <input 
                    type="text"
                    value={settings.siliconFlowModel}
                    onChange={(e) => setSettings({...settings, siliconFlowModel: e.target.value})}
                    placeholder="deepseek-ai/DeepSeek-R1"
                    className="w-full bg-gray-50 border border-gray-200 rounded p-2 text-xs font-mono outline-none focus:border-[#07c160]"
                  />
                  <p className="text-[10px] text-gray-400 mt-1">DeepSeek R1 无法识别图片。</p>
                 </div>
                 <div>
                  <label className="block text-xs text-gray-500 mb-1">视觉模型 (当发送图片时使用)</label>
                  <input 
                    type="text"
                    value={settings.siliconFlowVisionModel}
                    onChange={(e) => setSettings({...settings, siliconFlowVisionModel: e.target.value})}
                    placeholder="Qwen/Qwen2.5-VL-72B-Instruct"
                    className="w-full bg-gray-50 border border-gray-200 rounded p-2 text-xs font-mono outline-none focus:border-[#07c160]"
                  />
                 </div>
              </div>
            )}

            {/* Local Config */}
            {settings.provider === 'local' && (
              <div className="space-y-3 animate-fade-in">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">本地 API 地址</label>
                  <input 
                    type="text"
                    value={settings.localAIUrl}
                    onChange={(e) => setSettings({...settings, localAIUrl: e.target.value})} 
                    placeholder="http://localhost:11434/v1/chat/completions"
                    className="w-full bg-gray-50 border border-gray-200 rounded p-2 text-xs font-mono outline-none focus:border-[#07c160]"
                  />
                  <p className="text-[10px] text-gray-400 mt-1">需确保本地服务允许 CORS 跨域请求。</p>
                </div>
              </div>
            )}

             {/* Gemini Config */}
             {settings.provider === 'gemini' && (
              <div className="p-2 bg-blue-50 text-blue-800 rounded text-xs">
                使用内置 Gemini API (API Key 从环境变量读取)。支持多模态。
              </div>
            )}
            
            <div>
               <label className="block text-xs text-gray-500 mb-1">额外系统指令 (Prompt)</label>
               <textarea 
                  className="w-full border border-gray-200 rounded p-2 text-xs h-20 focus:border-[#95ec69] outline-none resize-none bg-gray-50"
                  value={settings.systemInstruction}
                  onChange={(e) => setSettings({...settings, systemInstruction: e.target.value})}
                  placeholder="适用于所有对话的额外规则..."
               />
            </div>
          </div>
        </section>

        {/* Local Sync Buttons */}
        <section className="pt-4 border-t border-gray-200">
           <h3 className="text-xs font-semibold text-gray-400 mb-3 uppercase tracking-wider">本地数据同步 (F:\聊天)</h3>
           <div className="text-xs text-gray-500 mb-3">
               请选择 <code>F:\聊天</code> 文件夹。系统将自动处理 <code>全局信息</code>、<code>聊天对象</code>、<code>聊天记录</code> 及 <code>头像</code> 子目录。
           </div>
           
           {/* Hidden Input for Folder Selection */}
           <input 
                type="file" 
                ref={folderInputRef}
                // @ts-ignore
                webkitdirectory="" 
                directory="" 
                multiple 
                className="hidden" 
                onChange={handleFolderSelect} 
           />

           <div className="grid grid-cols-2 gap-4">
                <button 
                    onClick={handleLoadFromFolder}
                    className="flex flex-col items-center justify-center p-4 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 transition-all shadow-sm group"
                >
                    <span className="text-2xl mb-2 group-hover:scale-110 transition-transform">📂</span>
                    <span className="font-medium text-gray-700">读取本地文件夹</span>
                    <span className="text-[10px] text-gray-400 mt-1">自动加载头像文件</span>
                </button>

                <button 
                    onClick={handleSaveToFolder}
                    className="flex flex-col items-center justify-center p-4 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 transition-all shadow-sm group"
                >
                    <span className="text-2xl mb-2 group-hover:scale-110 transition-transform">💾</span>
                    <span className="font-medium text-gray-700">保存到本地</span>
                    <span className="text-[10px] text-gray-400 mt-1">头像将存为独立图片</span>
                </button>
           </div>
           
           {(syncStatus || lastSyncTime) && (
                <div className="mt-3 text-center text-xs text-gray-500 bg-gray-100 p-2 rounded">
                    <div>{syncStatus}</div>
                    {lastSyncTime && <div>最后操作时间: {lastSyncTime}</div>}
                </div>
            )}
        </section>

      </div>
    </div>
  );
};

export default SettingsPanel;
